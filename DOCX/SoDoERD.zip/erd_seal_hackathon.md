# Sơ đồ ERD - Hệ thống quản lý cuộc thi SEAL Hackathon (ngành Kỹ thuật Phần mềm)

Tài liệu này mô tả thiết kế cơ sở dữ liệu cho hệ thống quản lý cuộc thi **SEAL Hackathon**, bao gồm việc quản lý thí sinh, đội thi, các vòng thi, bài dự thi, giám khảo, chấm điểm và giải thưởng.

## 1. Sơ đồ ERD tổng quan

```mermaid
erDiagram
    CUOCTHI ||--o{ VONGTHI : "gồm"
    CUOCTHI ||--o{ GIAITHUONG : "có"
    CUOCTHI ||--o{ NHATAITRO : "được tài trợ bởi"
    CUOCTHI ||--o{ DANGKY : "nhận"

    DOITHI ||--o{ THISINH : "gồm thành viên"
    DOITHI ||--o{ DANGKY : "thực hiện"
    DOITHI ||--o{ BAIDUTHI : "nộp"
    DOITHI |o--o{ GIAITHUONG : "đạt"
    DOITHI }o--o| MENTOR : "được hướng dẫn"

    VONGTHI ||--o{ BAIDUTHI : "tiếp nhận"

    BAIDUTHI ||--o{ DANHGIA : "được chấm"
    GIAMKHAO ||--o{ DANHGIA : "thực hiện"
    TIEUCHI ||--o{ DANHGIA : "dựa trên"

    CUOCTHI {
        int    MaCuocThi PK
        string TenCuocThi
        int    NamToChuc
        date   NgayBatDau
        date   NgayKetThuc
        string DiaDiem
        string TheLe
    }

    VONGTHI {
        int    MaVong PK
        int    MaCuocThi FK
        string TenVong
        int    ThuTu
        date   NgayBatDau
        date   NgayKetThuc
        string HinhThuc
    }

    THISINH {
        int    MaThiSinh PK
        int    MaDoi FK
        string HoTen
        string Email
        string SoDienThoai
        string Truong
        string Nganh
        string MSSV
        bool   LaTruongNhom
    }

    DOITHI {
        int    MaDoi PK
        int    MaMentor FK
        string TenDoi
        date   NgayThanhLap
        string TrangThai
    }

    DANGKY {
        int    MaDangKy PK
        int    MaDoi FK
        int    MaCuocThi FK
        date   NgayDangKy
        string TrangThaiDuyet
    }

    BAIDUTHI {
        int      MaBai PK
        int      MaDoi FK
        int      MaVong FK
        string   TenDuAn
        string   MoTa
        string   LinkSource
        string   LinkDemo
        datetime ThoiGianNop
    }

    GIAMKHAO {
        int    MaGiamKhao PK
        string HoTen
        string Email
        string ChuyenMon
        string DonVi
    }

    TIEUCHI {
        int     MaTieuChi PK
        string  TenTieuChi
        float   TrongSo
        int     DiemToiDa
        string  MoTa
    }

    DANHGIA {
        int    MaBai PK,FK
        int    MaGiamKhao PK,FK
        int    MaTieuChi PK,FK
        float  DiemSo
        string NhanXet
        date   NgayCham
    }

    GIAITHUONG {
        int    MaGiai PK
        int    MaCuocThi FK
        int    MaDoi FK
        string TenGiai
        string HangGiai
        string GiaTri
    }

    NHATAITRO {
        int    MaNhaTaiTro PK
        int    MaCuocThi FK
        string TenCongTy
        string HangTaiTro
        string GiaTriTaiTro
        string NguoiLienHe
    }

    MENTOR {
        int    MaMentor PK
        string HoTen
        string Email
        string ChuyenMon
        string CongTy
    }
```

## 2. Mô tả các thực thể (Entities)

| Thực thể | Ý nghĩa |
|----------|---------|
| **CUOCTHI** | Thông tin một mùa/kỳ cuộc thi SEAL Hackathon |
| **VONGTHI** | Các vòng thi trong một cuộc thi (Sơ loại, Bán kết, Chung kết...) |
| **THISINH** | Sinh viên tham gia, thuộc về một đội |
| **DOITHI** | Đội thi gồm nhiều thí sinh |
| **DANGKY** | Phiếu đăng ký dự thi của một đội cho một cuộc thi |
| **BAIDUTHI** | Sản phẩm/dự án đội nộp cho từng vòng |
| **GIAMKHAO** | Người chấm điểm các bài dự thi |
| **TIEUCHI** | Tiêu chí chấm điểm (kèm trọng số) |
| **DANHGIA** | Điểm số giám khảo chấm cho 1 bài theo 1 tiêu chí |
| **GIAITHUONG** | Giải thưởng của cuộc thi, trao cho đội thắng |
| **NHATAITRO** | Đơn vị tài trợ cho cuộc thi |
| **MENTOR** | Người hướng dẫn cho đội thi |

## 3. Mô tả các mối quan hệ (Relationships)

| Mối quan hệ | Loại | Diễn giải |
|-------------|------|-----------|
| CUOCTHI – VONGTHI | 1 : N | Một cuộc thi có nhiều vòng thi |
| CUOCTHI – DANGKY – DOITHI | N : M | Một đội đăng ký nhiều cuộc thi, một cuộc thi có nhiều đội (qua bảng DANGKY) |
| DOITHI – THISINH | 1 : N | Một đội gồm nhiều thí sinh |
| DOITHI – BAIDUTHI | 1 : N | Một đội nộp nhiều bài (mỗi vòng một bài) |
| VONGTHI – BAIDUTHI | 1 : N | Một vòng tiếp nhận nhiều bài dự thi |
| BAIDUTHI – GIAMKHAO – TIEUCHI | N : M : K | Bảng DANHGIA lưu điểm theo từng bài / giám khảo / tiêu chí |
| CUOCTHI – GIAITHUONG | 1 : N | Một cuộc thi có nhiều giải thưởng |
| DOITHI – GIAITHUONG | 1 : N | Một đội có thể đạt giải |
| CUOCTHI – NHATAITRO | 1 : N | Một cuộc thi có nhiều nhà tài trợ |
| MENTOR – DOITHI | 1 : N | Một mentor hướng dẫn nhiều đội |

> [!NOTE]
> Bảng **DANHGIA** là bảng trung gian với khóa chính tổ hợp `(MaBai, MaGiamKhao, MaTieuChi)` — cho phép nhiều giám khảo chấm cùng một bài trên nhiều tiêu chí khác nhau. Điểm tổng kết của bài sẽ được tính bằng `SUM(DiemSo * TrongSo)`.

> [!TIP]
> Nếu đề bài chỉ cần mức cơ bản, bạn có thể lược bỏ các thực thể **MENTOR**, **NHATAITRO** và **DANGKY** (gộp đăng ký trực tiếp vào quan hệ giữa DOITHI và CUOCTHI).
